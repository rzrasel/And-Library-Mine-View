# edittext-clearable
A sample create edittext-clearable using drawable.
