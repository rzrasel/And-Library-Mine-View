package com.flipkart.youtubeviewdemo.helper;

public class Constants {
    public static final String API_KEY = "your_api_key";
}
