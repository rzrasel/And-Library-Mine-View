package gr.escsoft.michaelprimez.searchablespinner.interfaces;

/**
 * Created by michael on 3/19/17.
 */

public interface IStatusListener {
    void spinnerIsOpening();
    void spinnerIsClosing();
}
