package com.jamper.searchspinner;

/**
 * Created by jamper on 12/11/2017.
 */

public interface CallBacks {

    public void setOnItemSelectedListener(OnItemSelected onItemSelected);


}
